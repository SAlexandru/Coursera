


public class Percolation {
	private final int N_;
	private byte[] board_;
	private byte[] isConnectedToTheFirstRow_;
	private byte[] isConnectedToTheLastRow_;
	private boolean isPercolating_;
	
	private WeightedQuickUnionUF union_;
	
	private static final short[] dx = new short[] {-1, 0, 0, 1};
	private static final short[] dy = new short[] {0, -1, 1, 0};
	
	
	private int getIdx (int i, int j) {return (i - 1) * N_ + j - 1;}
	
	private void setOpened (int idx) {board_[idx >> 3] |= 1 << (idx & 7);}
	private boolean isOpened  (int idx) {return 0 != (board_[idx >> 3] & (1 << (idx & 7))); }
	
	private void setConnectedToTheFirstRow (int idx) {isConnectedToTheFirstRow_[idx >> 3] |= 1 << (idx & 7);}
	private boolean isConnectedToTheFirstRow (int idx) {return 0 != (isConnectedToTheFirstRow_[idx >> 3] & (1 << (idx & 7))); }
	private byte getConnectedToTheFirstRow (int idx) {return isConnectedToTheFirstRow (idx) ? (byte)1: (byte)0;}
	
	private void setConnectedToTheLastRow (int idx) {isConnectedToTheLastRow_[idx >> 3] |= 1 << (idx & 7);}
	private boolean isConnectedToTheLastRow  (int idx) {return 0 != (isConnectedToTheLastRow_[idx >> 3] & (1 << (idx & 7))); }
	private byte getConnectedToTheLastRow (int idx) {return isConnectedToTheLastRow (idx) ? (byte)1: (byte)0;}
	
	public Percolation (int N) {
		if (N <= 0) {
			throw new IllegalArgumentException("The board size cannot be <= 0");
		}
		
		N_ = N;
		isPercolating_ = false;
		board_ = new byte[N_ * N_];
		isConnectedToTheFirstRow_ = new byte[N_ * N_];
		isConnectedToTheLastRow_ = new byte[N_ * N_];
		
		union_ = new WeightedQuickUnionUF(N_ * N_);
	}
	
	public void open (int i, int j) {
		int idx = getIdx (i, j);
		
		if (idx < 0 || idx >= N_ * N_) {
			throw new IndexOutOfBoundsException();
		}
		
		setOpened(idx);
		
		if (1 == i) {
			setConnectedToTheFirstRow(idx);
		}
		
		if (N_ == i) {
			setConnectedToTheLastRow(idx);
		}
		
		for (int k = 0; k < dx.length; ++k) {
			int newIdx = getIdx (i + dx[k], j + dy[k]);
			
			if (newIdx < 0 || newIdx >= N_ * N_) continue;
			
			if ( isOpened(newIdx) ) {
				union_.union(idx, newIdx);
				
				int root = union_.find(newIdx);
				isConnectedToTheFirstRow_[idx >> 3] |= getConnectedToTheFirstRow(root >> 3) << (idx & 7);
				isConnectedToTheLastRow_[idx >> 3] |= getConnectedToTheLastRow(root >> 3) << (idx & 7);
				isConnectedToTheFirstRow_[idx >> 3] |= getConnectedToTheFirstRow(newIdx >> 3) << (idx & 7);
				isConnectedToTheLastRow_[idx >> 3] |= getConnectedToTheLastRow(newIdx >> 3) << (idx & 7);
			}
		}
		
		for (int k = 0; k < dx.length; ++k) {
			int newIdx = getIdx (i + dx[k], j + dy[k]);
			
			if (newIdx < 0 || newIdx >= N_ * N_) continue;
			
			if ( isOpened(newIdx) ) {
				int root = union_.find(newIdx);
				
				isConnectedToTheFirstRow_[newIdx >> 3] |= getConnectedToTheFirstRow(idx >> 3) << (idx & 7);
				isConnectedToTheLastRow_[newIdx >> 3] |= getConnectedToTheLastRow(idx >> 3) << (idx & 7);
				isConnectedToTheFirstRow_[root >> 3] |= getConnectedToTheFirstRow(idx >> 3) << (idx & 7);
				isConnectedToTheLastRow_[root >> 3] |= getConnectedToTheLastRow(idx >> 3) << (idx & 7);
				
				isPercolating_ = isPercolating_ ||
						(isConnectedToTheFirstRow(newIdx) && isConnectedToTheLastRow(newIdx));
				isPercolating_ = isPercolating_ ||
						(isConnectedToTheFirstRow(root) && isConnectedToTheLastRow(root));
			}
		}
		
		

		isPercolating_ = isPercolating_ ||
				(isConnectedToTheFirstRow(idx) && isConnectedToTheLastRow(idx));
		
	}
	
	public boolean isOpen (int i, int j) {
		int idx = getIdx(i, j);
		
		if (idx < 0 || idx >= N_ * N_) throw new IllegalArgumentException();
		return isOpened(idx);
	}
	
	public boolean isFull (int i, int j) {
		int idx = getIdx(i, j);
		
		if (idx < 0 || idx >= N_ * N_) throw new IllegalArgumentException();
		if (isConnectedToTheFirstRow(union_.find(idx))) {
			setConnectedToTheFirstRow(idx);
		}
		return isConnectedToTheFirstRow(idx);
	}
	
	public boolean percolates() {
		return isPercolating_;
	}
	
	public static void main(String[] args) {
	}
}
